﻿using SQLite4Unity3d;
using UnityEngine;
using System.Linq;
using System;

#if !UNITY_EDITOR
using System.Collections;
using System.IO;
#endif
using System.Collections.Generic;
///<summary>
/// Deals With coections to the database 
/// Most of this is not my code and has been obtained from outside sorces
/// My own code starts from Line 189
///</summary>
public class DataService {

    private SQLiteConnection _connection;
    private Player lcresult;
    private int lcStoryState;
    

    public SQLiteConnection Connection
    {
        get
        {
            return _connection;
        }
    }
    public DataService(string DatabaseName) {

#if UNITY_EDITOR
        var dbPath = string.Format(@"Assets/StreamingAssets/{0}", DatabaseName);
#else
        // check if file exists in Application.persistentDataPath
        var filepath = string.Format("{0}/{1}", Application.persistentDataPath, DatabaseName);

        if (!File.Exists(filepath))
        {
            Debug.Log("Database not in Persistent path");
            // if it doesn't ->
            // open StreamingAssets directory and load the db ->

#if UNITY_ANDROID
            var loadDb = new WWW("jar:file://" + Application.dataPath + "!/assets/" + DatabaseName);  // this is the path to your StreamingAssets in android
            while (!loadDb.isDone) { }  // CAREFUL here, for safety reasons you shouldn't let this while loop unattended, place a timer and error check
            // then save to Application.persistentDataPath
            File.WriteAllBytes(filepath, loadDb.bytes);
#elif UNITY_IOS
                 var loadDb = Application.dataPath + "/Raw/" + DatabaseName;  // this is the path to your StreamingAssets in iOS
                // then save to Application.persistentDataPath
                File.Copy(loadDb, filepath);
#elif UNITY_WP8
                var loadDb = Application.dataPath + "/StreamingAssets/" + DatabaseName;  // this is the path to your StreamingAssets in iOS
                // then save to Application.persistentDataPath
                File.Copy(loadDb, filepath);

#elif UNITY_WINRT
		var loadDb = Application.dataPath + "/StreamingAssets/" + DatabaseName;  // this is the path to your StreamingAssets in iOS
		// then save to Application.persistentDataPath
		File.Copy(loadDb, filepath);
		
#elif UNITY_STANDALONE_OSX
		var loadDb = Application.dataPath + "/Resources/Data/StreamingAssets/" + DatabaseName;  // this is the path to your StreamingAssets in iOS
		// then save to Application.persistentDataPath
		File.Copy(loadDb, filepath);
#else
	var loadDb = Application.dataPath + "/StreamingAssets/" + DatabaseName;  // this is the path to your StreamingAssets in iOS
	// then save to Application.persistentDataPath
	File.Copy(loadDb, filepath);

#endif

            Debug.Log("Database written");
        }

        var dbPath = filepath;
#endif
        _connection = new SQLiteConnection(dbPath, SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create);
        Debug.Log("Final PATH: " + dbPath);

    }


    /*
     * New Create method and data storage methods
     * ===========================================================================================================
     * 
     */

    /*
     * Create database tables
     * from a list of Table types
     */
    public void CreateDB(System.Type[] pTableTypes)
    {

        // Gnarly (using Linq) lambda trick in place of a loop, build the "Where"s then execute with a ToList, 
        var createList = pTableTypes.Where<System.Type>(x =>
                   {
                       _connection.CreateTable(x);
                       return true;
                   }
            ).ToList();


    }

    /*
     * Store the value in a "Record" of a table type T
     * Includes update, and insert
     * returns unique autoincrement id 
     */
    public void Store<T>(T Record)
    {
        _connection.InsertOrReplace(Record);

    }

    public void StoreIfNotExists<T>(T Record)
    {

        try
        {
            _connection.Insert(Record);
        }
        catch (Exception E)
        {
            Debug.Log(E.InnerException.Message);
        }

    }

    public void StoreAllIfNotExists<T>(T[] RecordList)
    {

        try
        {
            _connection.InsertAll(RecordList);
        }
        catch (Exception E)
        {
            Debug.Log(E.InnerException.Message);
        }
    }
      
    
    public int StoryCount()
    {
        int result = _connection.Table<Story>().ToList<Story>().Count;
        return result;

    }

   /// <summary>
   /// When a new game is requested this method resets all the tables needed for game play
   /// Meaning the player info in the table will be reset to defult.
   /// </summary>
    public void NewGame()
    {
        /*
             Runs when a new game is created.
             Deletes database entrys used by spasific user.
             And inputs defults back into the database under there user name
             Currently does not work will only work the first time a game is run
             Due to there being no table entrys to delete.

        */
        #region Insert Scenes

        _connection.Query<Scene>("delete from Scene where Scene.PlayerName = ?",
            SaveDataBetweenScenes.GameInstance.UserName);


        _connection.InsertAll(new Scene[]{
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "InCell",
                SceneState = 1,
            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "TrainingRoom",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "HallWay",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "StorageRoom",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "MapRoom",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "BreakRoom",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "WineCeller",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "BossRoom",
                SceneState = 1,

            },
            new Scene{
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneID = "OutSideFredom",
                SceneState = 1,

            }
        });
        #endregion
        #region Insert Player
        Player Player = new Player();
        Player = CheckPlayerGame(SaveDataBetweenScenes.GameInstance.UserName);
        Player.CurrentScene = "InCell";
        NewGameUpdatePlayer(Player);
        #endregion
        #region Insert Inventory

        _connection.Query<InventoryItem>("delete from InventoryItem where InventoryItem.PlayerName = ?",
            SaveDataBetweenScenes.GameInstance.UserName);
        #endregion
        #region Insert SceneItems

        _connection.Query<SceneItem>("delete from SceneItem where SceneItem.PlayerName = ?",
            SaveDataBetweenScenes.GameInstance.UserName);

        _connection.InsertAll(new SceneItem[]
        {
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "TrainingRoom",
                ItemId = 1,
                BeenPickedUp = 1

            },
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "HallWay",
                ItemId = 2,
                BeenPickedUp = 1

            },
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "StorageRoom",
                ItemId = 3,
                BeenPickedUp = 1

            },
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "MapRoom",
                ItemId = 4,
                BeenPickedUp = 1

            },
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "BreakRoom",
                ItemId = 5,
                BeenPickedUp = 1

            },
            new SceneItem
            {
                PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                SceneId  = "WineCeller",
                ItemId = 6,
                BeenPickedUp = 1

            },
        });
        #endregion
        GameManager.gameModel.GetPlayer();

    }
    /// <summary>
    /// When the program is first started up this method will created the entire database and insert the proper data
    /// </summary>
    public void CreateDB()
    {
    /*
      Creates the entire SQLLight datbase
      Inputs data that will be generic for every player
      Doesnot input data if table is used by a player for in game stats
    */
        #region Insert Scenes
        _connection.DropTable<Scene> ();
		_connection.CreateTable<Scene> ();

        
        #endregion

        #region Insert Story
        _connection.DropTable<Story>();
        _connection.CreateTable<Story>();

        _connection.InsertAll(new Story[]{
            new Story{

                StoryName = "InCell",
                Description = "You Exit Your Cell. You See Two Doors.One To The East And One To The West",
                State = 1,
                FirstSceneID = "InCell",
                SceneID = "InCell",
                

            },
            new Story{
                StoryName = "TrainingRoomItemsPresent",
                Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthWest A Door To The West And A Door To The North." + "\n" + "\n" + "You See an Old Rusty Sword",
                State = 1,
                SceneID = "TrainingRoom",
            },
            new Story{
                StoryName = "TrainingRoomItemsPresentNoItems",
                Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthWest A Door To The West And A Door To The North.",
                State = 2,
                SceneID = "TrainingRoom",
            },
            new Story{
                StoryName = "TrainingRoomPickedUpItem",
                Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthWest A Door To The West And A Door To The North." + "\n" + "\n" + "You Picked Up The Sword",
                State = 3,
                SceneID = "TrainingRoom",
            },
            new Story{
                StoryName = "HallWayItemsPresent",
                Description = "You Head Through The Door And Follow The Hall Into A Room There Is A Long Hall Way To The North And A Door To The East." + "\n" + "\n" + " You see something on the ground",
                State = 1,
                SceneID = "HallWay",
            },
            new Story{
                StoryName = "HallWayNoItems",
                Description = "You Head Through The Door And Follow The Hall Into A Room There Is A Long Hall Way To The North And A Door To The East.",
                State = 2,
                SceneID = "HallWay",
            },
            new Story{
                StoryName = "HallWayPickedUpItem",
                Description = "You Head Through The Door And Follow The Hall Into A Room There Is A Long Hall Way To The North And A Door To The East." + "\n" + "\n" + " You Picked up a Rock Yay??...",
                State = 3,
                SceneID = "HallWay",
            },
            new Story{
                StoryName = "StorageRoomItemsPresent",
                Description = "You Enter A Room Full Of Boxes You Can See A Door To The East And A Door To Your South." + "\n" + "\n" + " You See A Crate Full Of Bread",
                State = 1,
                SceneID = "StorageRoom",
            },
            new Story{
                StoryName = "StorageRoomNoItems",
                Description = "You Enter A Room Full Of Boxes You Can See A Door To The East And A Door To Your South.",
                State = 2,
                SceneID = "StorageRoom",
            },
            new Story{

                StoryName = "StorageRoomPickedUpItem",
                Description = "You Enter A Room Full Of Boxes You Can See A Door To The East And A Door To Your South." + "\n" + "\n" + " You Took Some Bread",
                State = 3,
                SceneID = "StorageRoom",
            },
            new Story{

                StoryName = "MapRoomItemsPresent",
                Description = "You Find YourSelf In A Map Room. It Is A Dead End The Only Way Out Is The Door To Your West." + "\n" + "\n" + " You See A Map On The Table",
                State = 1,
                SceneID = "MapRoom",
            },
            new Story{

                StoryName = "MapRoomNoItems",
                Description = "You Find YourSelf In A Map Room. It Is A Dead End The Only Way Out Is The Door To Your West.",
                State = 2,
                SceneID = "MapRoom",
            },
            new Story{

                StoryName = "MapRoomPickedUpItem",
                Description = "You Find YourSelf In A Map Room. It Is A Dead End The Only Way Out Is The Door To Your West." + "\n" + "\n" + " You Picked Up The Map",
                State = 3,
                SceneID = "MapRoom",
            },
            new Story{

                StoryName = "BreakRoomItemsPresent",
                Description = "You Find YourSelf In An Open Room That Looks Like A BreakRoom For The Guards. You Can See An Open Room To The North A Door To Your East And A HallWay To Your South." + "\n" + "\n" + "You See Some Worn Out Armour In The Corner",
                State = 1,
                SceneID = "BreakRoom",
            },
            new Story{

                StoryName = "BreakRoomNoItems",
                Description = "You Find YourSelf In An Open Room That Looks Like A BreakRoom For The Guards. You Can See An Open Room To The North A Door To Your East And A HallWay To Your South.",
                State = 2,
                SceneID = "BreakRoom",
            },
            new Story{

                StoryName = "BreakRoomPickedUpItem",
                Description = "You Find YourSelf In An Open Room That Looks Like A BreakRoom For The Guards. You Can See An Open Room To The North A Door To Your East And A HallWay To Your South." + "\n" + "\n" + "You Put On The Armor Better Than Nothing",
                State = 3,
                SceneID = "BreakRoom",
            },
            new Story{

                StoryName = "WineCellerItemsPresent",
                Description = "You Find YourSelf In A Wine Celler. You Can Hear FootSteps Thought The Door To Your East. There Is Also The PassageWay To Your South" + "\n" + "\n" + "You See A Potion On The Shelf Could Be Useful",
                State = 1,
                SceneID = "WineCeller",
            },
            new Story{

                StoryName = "WineCellerNoItems",
                Description = "You Find YourSelf In A Wine Celler. You Can Hear FootSteps Thought The Door To Your East. There Is Also The PassageWay To Your South",
                State = 2,
                SceneID = "WineCeller",
            },
            new Story{

                StoryName = "WineCellerPickedUpItem",
                Description = "You Find YourSelf In A Wine Celler. You Can Hear FootSteps Thought The Door To Your East. There Is Also The PassageWay To Your South" + "\n" + "\n" + "You Found A Health Potion",
                State = 3,
                SceneID = "WineCeller",
            },
            new Story{

                StoryName = "BossRoom",
                Description = "You Come Across A Gaurd You Must Kill Them To Escape Type Attack Boss To Attack  The Guard",
                State = 1,
                SceneID = "BossRoom",
            },
            new Story{

                StoryName = "OutSideFredom",
                Description = "You Escaped Hurray!!! But Then Again The Cell Was Quiet Nice.....",
                State = 1,
                SceneID = "OutSideFredom",
            },
        });
        #endregion

        #region Insert Directions
        _connection.DropTable<SceneDirection>();
        _connection.CreateTable<SceneDirection>();

        _connection.InsertAll(new SceneDirection[]
        {
            new SceneDirection
            {
                ID ="InCellWest",
                SceneID = "InCell",
                ToSceneId = "HallWay",
                Command = "go west"

            },
            new SceneDirection
            {
                ID ="InCellEast",
                SceneID = "InCell",
                ToSceneId = "TrainingRoom",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="TrainingRoomNorth",
                SceneID = "TrainingRoom",
                FromSceneId = "TrainingRoom",
                ToSceneId = "StorageRoom",
                Command = "go north"

            },
            new SceneDirection
            {
                ID ="TrainingRoomWest",
                SceneID = "TrainingRoom",
                FromSceneId = "TrainingRoom",
                ToSceneId = "InCell",
                Command = "go west"

            },
            new SceneDirection
            {
                ID ="TrainingRoomNorthWest",
                SceneID = "TrainingRoom",
                FromSceneId = "TrainingRoom",
                ToSceneId = "BreakRoom",
                Command = "go northwest"

            },
            new SceneDirection
            {
                ID ="HallWayNorth",
                SceneID = "HallWay",
                FromSceneId = "HallWay",
                ToSceneId = "BreakRoom",
                Command = "go north"

            },
            new SceneDirection
            {
                ID ="HallWayEast",
                SceneID = "HallWay",
                FromSceneId = "HallWay",
                ToSceneId = "InCell",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="StorageRoomEast",
                SceneID = "StorageRoom",
                FromSceneId = "StorageRoom",
                ToSceneId = "MapRoom",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="StorageRoomSouth",
                SceneID = "StorageRoom",
                FromSceneId = "StorageRoom",
                ToSceneId = "TrainingRoom",
                Command = "go south"

            },
            new SceneDirection
            {
                ID ="MapRoomWest",
                SceneID = "MapRoom",
                FromSceneId = "MapRoom",
                ToSceneId = "StorageRoom",
                Command = "go west"

            },
            new SceneDirection
            {
                ID ="BreakRoomNorth",
                SceneID = "BreakRoom",
                FromSceneId = "BreakRoom",
                ToSceneId = "WineCeller",
                Command = "go north"

            },
            new SceneDirection
            {
                ID ="BreakRoomSouth",
                SceneID = "BreakRoom",
                FromSceneId = "BreakRoom",
                ToSceneId = "HallWay",
                Command = "go south"

            },
            new SceneDirection
            {
                ID ="BreakRoomEast",
                SceneID = "BreakRoom",
                FromSceneId = "BreakRoom",
                ToSceneId = "TrainingRoom",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="WineCellerSouth",
                SceneID = "WineCeller",
                FromSceneId = "WineCeller",
                ToSceneId = "BreakRoom",
                Command = "go south"

            },
            new SceneDirection
            {
                ID ="WineCellerEast",
                SceneID = "WineCeller",
                FromSceneId = "WineCeller",
                ToSceneId = "BossRoom",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="BossRoomWest",
                SceneID = "BossRoom",
                FromSceneId = "BossRoom",
                ToSceneId = "WineCeller",
                Command = "go west"

            },
            new SceneDirection
            {
                ID ="BossRoomEast",
                SceneID = "BossRoom",
                FromSceneId = "BossRoom",
                ToSceneId = "OutSideFredom",
                Command = "go east"

            },
            new SceneDirection
            {
                ID ="OutSideWest",
                SceneID = "OutSideFredom",
                FromSceneId = "OutSideFredom",
                ToSceneId = "BossRoom",
                Command = "go west"

            },
        });
        #endregion

        #region Insert Items
        _connection.DropTable<Item>();
        _connection.CreateTable<Item>();

        _connection.InsertAll(new Item[]
        {
            new Item
            {
                ItemId = 1,
                Description ="Sword",
                Effect = 1

            },
            new Item
            {
                ItemId = 2,
                Description ="Rock",
                Effect = 2

            },
            new Item
            {
                ItemId = 3,
                Description ="Bread",
                Effect = 3

            },
            new Item
            {
                ItemId = 4,
                Description ="Map"
                

            },
            new Item
            {
                ItemId = 5,
                Description ="Crude Armor",
                Effect = 4

            },
            new Item
            {
                ItemId = 6,
                Description ="Health Potion",
                Effect = 5

            },
        });
        #endregion

        #region Insert SceneItems
        _connection.DropTable<SceneItem>();
        _connection.CreateTable<SceneItem>();
          
        #endregion

        #region Insert Enemys
        _connection.DropTable<Enemy>();
        _connection.CreateTable<Enemy>();

        _connection.InsertAll(new Enemy[]
        {
            new Enemy
            {
                EnemyName = "Boss",
                HP = 100,
                Damage = 25

            },
        });
        #endregion
               
        #region Insert Player
        _connection.DropTable<Player>();
        _connection.CreateTable<Player>();
        #endregion

        #region Insert Inventory
        _connection.DropTable<InventoryItem>();
        _connection.CreateTable<InventoryItem>();
        #endregion

        

    }

    
    /// <summary>
    /// Checks to see if player exists and returns it back for use
    /// </summary>
    /// <param name="prUserName"></param>
    /// <returns> Player Row </returns>
    public Player CheckPlayerGame(string prUserName)
    {
        return _connection.Table<Player>().Where(x => x.PlayerEmail == prUserName).FirstOrDefault();

    }

    /// <summary>
    /// Gets enemy stats and returns them to be used in code
    /// </summary>
    /// <param name="prEnemyName"></param>
    /// <returns> Enemy Row </returns>
    public Enemy GetEnemyStats(string prEnemyName)
    {
        return _connection.Table<Enemy>().Where(x => x.EnemyName == prEnemyName).FirstOrDefault();

    }
   
    /// <summary>
    /// Gets and returns current scene
    /// </summary>
    /// <param name="prScene"></param>
    /// <returns> Scene Row </returns>
    public Scene GetCurrentScene(string prScene)
    {
        return _connection.Table<Scene>().Where(x => x.SceneID == prScene).FirstOrDefault();

    }
    
    /// <summary>
    /// Gets and returns a list of players current scene
    /// Used for deleteing
    /// </summary>
    /// <param name="prPlayerName"></param>
    /// <returns> List of scenes </returns>
    public List<Scene> GetPlayerScenes(string prPlayerName)
    {
        List<Scene> lcScene =  _connection.Table<Scene>().Where(x => x.PlayerName == prPlayerName).ToList();
        return lcScene;
        
    }

    /// <summary>
    /// Gets all invetory items to be displayed on player screen
    /// </summary>
    /// <param name="prPlayerName"></param>
    /// <returns> List of inventory Items </returns>
    public List<InventoryItem> GetAllInventoryItems(string prPlayerName)
    {
        List<InventoryItem> lcInv = _connection.Table<InventoryItem>().Where(x => x.PlayerName == prPlayerName).ToList();
        return lcInv;
    }

    /// <summary>
    /// Gets and returns one inventory item
    /// </summary>
    /// <param name="prItemID"></param>
    /// <returns> returns one inventory row </returns>
    public InventoryItem GetInventoryItem(int prItemID)
    {
        return _connection.Table<InventoryItem>().Where(x => x.ItemID == prItemID).FirstOrDefault();
        
    }
   
    /// <summary>
    /// gets an retuns one item used for getting accsess to item id
    /// </summary>
    /// <param name="prItemID"></param>
    /// <returns> Item Row </returns>
    public Item GetItem(int prItemID)
    {
        return _connection.Table<Item>().Where(x => x.ItemId == prItemID).FirstOrDefault();
        
    }
    
    /// <summary>
    ///  Used for updateing player scenes
    /// </summary>
    /// <param name="prScene"></param>
    public void UpdateCurrentScene(Player prScene)
    {
         _connection.Update(prScene);

    }
   
    /// <summary>
    /// Used for delteing inventory items
    /// </summary>
    /// <param name="prItem"></param>
    public void DeleteItem( InventoryItem prItem)
    {
        _connection.Delete(prItem);

    }
   
    /// <summary>
    /// Used for deleteing a list of inventory items
    /// </summary>
    /// <param name="prItem"></param>
    public void NewGameDeleteOldInventory(List<InventoryItem> prItem)
    {
        foreach (InventoryItem lcInv in prItem)
        {
            _connection.Delete(prItem);
        }
       

    }
    
    /// <summary>
    ///  Used for deleting a list of old player scene items
    /// </summary>
    /// <param name="prPlayerSceneItems"></param>
    public void NewGameDeleteOldSceneItems(List<SceneItem> prPlayerSceneItems)
    {
        foreach (SceneItem lcSceneItem in prPlayerSceneItems)
        {
            _connection.Delete(prPlayerSceneItems);
        }


    }
   
    /// <summary>
    /// Used for deleting a list of old player scenes
    /// </summary>
    /// <param name="prPlayerScenes"></param>
    public void NewGameDeleteOldScenes(List<Scene> prPlayerScenes)
    {
        foreach (Scene lcScene in prPlayerScenes)
        {
            _connection.Delete(prPlayerScenes);
        }


    }
   
    /// <summary>
    /// Used for updateing player scenes
    /// </summary>
    /// <param name="prScene"></param>
    public void UpdateCurrentSceneState(Scene prScene)
    {
        _connection.Update(prScene);

    }
   
    /// <summary>
    /// Used for updating player scene items
    /// </summary>
    /// <param name="prScene"></param>
    public void UpdateCurrentSceneItems(SceneItem prScene)
    {
        _connection.Update(prScene);

    }
    
    /// <summary>
    /// Used for updateing player
    /// </summary>
    /// <param name="prPlayer"></param>
    public void NewGameUpdatePlayer(Player prPlayer)
    {
        _connection.Update(prPlayer);

    }
   
    /// <summary>
    /// Used for getting and setting the next scene the player goes to.
    /// In a try catch because if direction does not exist the query would crash
    /// This makes sure it will return a null value if it does not exist
    /// </summary>
    /// <param name="prScene"></param>
    /// <param name="prState"></param>
    /// <returns> SceneDirection row if exists </returns>
    public SceneDirection GetNewDirection(string prScene, string prState)
    {
        try
        {
            return _connection.Table<SceneDirection>().Where<SceneDirection>(x => x.SceneID == prScene && x.Command == prState).First<SceneDirection>();
        }
        catch
        {
            return null;
        }
        
        
    }

    /// <summary>
    /// Gets a scene item
    /// </summary>
    /// <param name="prScene"></param>
    /// <returns> SceneItem row </returns>
    public SceneItem GetCurrentSceneItem(string prScene)
    {
        return _connection.Table<SceneItem>().Where(x => x.SceneId == prScene).FirstOrDefault();

    }
    
    /// <summary>
    ///  Gets a list of scene items.
    ///  Used for deleteing
    /// </summary>
    /// <param name="prPlayerName"></param>
    /// <returns> List of sceneitems </returns>
    public List<SceneItem> NewGameGetOldSceneItems(string prPlayerName)
    {
        List<SceneItem> lcSceneItem = _connection.Table<SceneItem>().Where(x => x.PlayerName == prPlayerName).ToList();
        return lcSceneItem;
    }

    /// <summary>
    /// Gets current story from SQL light database
    /// </summary>
    /// <param name="prScene"></param>
    /// <param name="prState"></param>
    /// <returns> Story row </returns>
    public Story GetCurrentStory(string prScene, int prState)
    {
        
         return _connection.Table<Story>().Where<Story>(x => x.SceneID == prScene && x.State == prState).First<Story>();
        

        
    }

    /*
      My code I want t remember just in case
    */
            //"select Scene.SceneID,Story.State,Story.Description"
            //+ "inner join Scene"
            //+ "on Scene.SceneID = Story.SceneID"
            //+ "where Scene.SceneID = ? and Story.State = ?",
            //GameManager.gameModel.CurrentScene, prState).ToList();

            //lcStoryState = lcStory[0]

    
    /// <summary>
    /// Everything below is not my code and is not used.
    /// </summary>
    public IEnumerable<Person> GetPersons()
    {
        return _connection.Table<Person>();
    }

    public IEnumerable<Person> GetPersonsNamedRoberto()
    {
        return _connection.Table<Person>().Where(x => x.Name == "Roberto");
    }

    public Person CreatePerson(){
		var p = new Person{
				Name = "Johnny",
				Surname = "Mnemonic",
				Age = 21
		};
		_connection.Insert (p);
		return p;
	}

    
}
