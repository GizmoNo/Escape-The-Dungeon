﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// Not used
/// Idea what did not work
/// </summary>
public class UpdateStory : MonoBehaviour {

	public Text output;


    // Use this for initialization
    public void UpdateStoryOnClick()
    {
        output.text = GameManager.gameModel.Story();
    }
}
