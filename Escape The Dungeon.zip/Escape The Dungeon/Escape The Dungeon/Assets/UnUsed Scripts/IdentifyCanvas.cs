﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdentifyCanvas : MonoBehaviour
{

    // Use this for initialization
//    void Start()
//    {
//        //Code below looks for all my canvases and sets them in the code to be used/referenced to.
//        Canvas[] lcCanvases = gameObject.GetComponents<Canvas>();
//        Canvas lcCanvas = lcCanvases[0];
//        string lcName = lcCanvas.name;

        
//        if (GameManager.Canvases != null)
//        {
//            GameManager.Canvases.Add(lcName, lcCanvas);
//            Debug.Log("I added a canvas " + lcName);
//        }
//        else
//        {
//            Debug.Log("Canvas " + lcName + " not added");
//        }
//    }

}
