﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;
/// <summary>
/// Class that creats the user database table
/// </summary>
public class Users
{
    [PrimaryKey]
    public string UserName { get; set; }
    [NotNull]
    public string PassWord { get; set; }
	
}
