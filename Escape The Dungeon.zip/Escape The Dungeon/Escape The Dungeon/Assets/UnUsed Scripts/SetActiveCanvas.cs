﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Class that deals with setting the active canvas
/// </summary>
public class SetActiveCanvas : MonoBehaviour
{

    // Use this for initialization
    //Sets active canvas when game first starts.
    void Start()
    {
        Canvas[] lcCanvases = gameObject.GetComponents<Canvas>();
        Canvas lcCanvas = lcCanvases[0];
        string lcName = lcCanvas.name;
        if (GameManager.instance != null)
            // Do we need to check if we already have this name?
            GameManager.instance.setActiveCanvas(lcName);

    }
}
