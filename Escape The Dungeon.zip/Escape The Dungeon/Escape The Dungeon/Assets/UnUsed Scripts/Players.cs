﻿using System;
using System.Collections;
using System.Collections.Generic;

using System.IO;

/// <summary>
/// Temp Setup for when we implament multiplayer.
/// </summary>

public class Players
{
    private List<Player> _players = new List<Player>();

    public Player this[int index]
    {
        get
        {
            return _players[index];
        }
        set
        {
            _players[index] = value;
        }
    }

    public Players()
    {

    }
}
