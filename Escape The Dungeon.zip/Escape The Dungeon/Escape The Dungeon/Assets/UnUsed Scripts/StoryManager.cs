﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using System.Linq;



///*
// * The Story Manager 
// * - makes stories
// * - persists stories
// */
//public class StoryManager
//{
//    private Scene _FirstScene;
//    private DataService Db = new DataService("EscapeTheDungeon.db");
//    public DataService DB
//    {
//        get
//        {
//            return Db;
//        }
//    }

//    public Scene FirstScene
//    {
//        get
//        {
//            return _FirstScene;
//        }

//    }

//    /*
//     *  Story Manager
//     *  When the story manager is constructed:
//     *  1. the Db data service is asked to create the database tables if they do not exist. 
//     *  2. ask the Db data service to create the Scenes by inserting(updating) values into the Scene, and SceneDirection, Item and SceneItem tables.
//     */
//    public StoryManager()
//    {
//        /*
//         * Create database tables if they do not exist.
//         * - a call to create a db from a list of System.Type - 
//         * - the C# "typeof" operator returns a System.Type value.
//         * 
//         */
//        Db.CreateDB(new[] {
//            typeof(Story),
//            typeof(Scene),
//            typeof(Item),
//            typeof(SceneItem),
//            typeof(SceneDirection),
//            typeof(Player),
//            typeof(InventoryItem),

//       });

//        if (Db.StoryCount() == 0)
//        {
//            MakeStory("Escape The Dungeon","My Game");
//        }
//        else
//            Db.Connection.DropTable<Story>();
//            Db.Connection.DropTable<Scene>();
//            Db.Connection.DropTable<Item>();
//            Db.Connection.DropTable<SceneItem>();
//            Db.Connection.DropTable<SceneDirection>();
//            Db.Connection.DropTable<Player>();
//            Db.Connection.DropTable<InventoryItem>();
//        MakeStory("Escape The Dungeon", "My Game");


//    }
//    /*
//     * GetStory
//     * Gets the Story record and sets the Story for the GameModel
//     */
//    public void GetStory(string pStoryName)
//    {
//        //GetStoryFirstScene(pStoryName);
//    }

//    /*
//     * Make Story
//     * Adds a Story record for a named story
//     * Adds Scenes and Items if they do not exist.
//     */
//    public void MakeStory(string pStoryName, string pStoryDescription)
//    {
//        Db.StoreIfNotExists(new Story
//        {
//            StoryName = pStoryName,
//            Description = pStoryDescription
//        });


//        /*
//         * Get the Story Back so we can update the FirstScene when we have it, using Linq
//         * 
//         * Build a "where lambda", execute with ToList, then get the first one from the list
//         */
//        Story StoryID = Db.Connection.Table<Story>().Where(
//                   x => x.StoryName == pStoryName
//                   ).ToList<Story>().FirstOrDefault<Story>();

//        /*
//         *  The Scenes that make up the Story
//         *  This Insert returns the Autoincrement ID
//         */
//        #region In Cell Scene
//        // Cell
//        //Crate Cell Scene
//        var lcCellScene = new Scene
//        {
//            StoryName = StoryID.StoryName,
//            StoryState = 1
            
//        };
//        Db.Connection.Insert(lcCellScene);
//        string lcCellID = lcCellScene.SceneID;

//        // Now we have our first Scene for the story
//       // StoryID.FirstSceneID = lcCellID;
//        //Db.Connection.InsertOrReplace(StoryID);

//        //Create Story Text No Item In This Scene
//        var lcCellStory = new Story
//        {
//            StoryName = StoryID.StoryName,

//            State = 1,

//            Description = "You Exit Your Cell. You See Two Doors.One To The East And One To The West",

//            FirstSceneID = lcCellID
       
//        };
//        Db.Connection.Insert(lcCellStory);
//        int lcCellState = lcCellStory.State;

//        #endregion

//        #region Training Room Scene

//        var lcTrainingRoom = new Scene
//        {
//            StoryName = StoryID.StoryName,
//            StoryState = 1

//        };
//        Db.Connection.Insert(lcCellScene);
//        string lcTrainingRoomID = lcTrainingRoom.SceneID;

//        var TrainingRoomStoryNoItems = new Story
//        {
//            StoryName = StoryID.StoryName,

//            State = 1,

//            Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthEast A Door To The East And A Door To The North.",

            

//        };
//        Db.Connection.Insert(lcCellStory);
//        int lcTrainingRoomState = TrainingRoomStoryNoItems.State;

//        var TrainingRoomStoryItemsPresent = new Story
//        {
//            StoryName = StoryID.StoryName,

//            State = 2,

//            Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthEast A Door To The East And A Door To The North." + "\n" + "\n" + "You See an Old Rusty Sword",

            

//        };
//        Db.Connection.Insert(lcCellStory);
        

//        var TrainingRoomStoryItemJustPickedUp = new Story
//        {
//            StoryName = StoryID.StoryName,

//            State = 3,

//            Description = "You Head Thought The Door And Find YourSelf In A Circle Room. There Is A Hall To The NorthEast A Door To The East And A Door To The North." + "\n" + "\n" + "You Picked Up The Sword",

            

//        };
//        Db.Connection.Insert(lcCellStory);
        















//        #endregion



























































//        // Mall
//        var lcMall = new Scene
//        {
//            StoryName = StoryID.StoryName,
//            StoryState = 0
//        };
//        Db.Connection.Insert(lcMall);
//        string lcMallID = lcMall.SceneID;

//        // Mall Items, wallet, key, gold. Inserts a record for each into the Item table.
//        Item[] lcItems = {
//                 new Item
//                 {
//                    Description = "A Wallet"
//                },
//                new Item
//                {
//                    Description = "A key"
//                },
//                new Item
//                {
//                    Description = "Gold"
//                }
//            };
//        // Insert Items, they will now get their ID back
//        lcItems.Where(x =>
//        {
//            Db.Connection.Insert(x);

//            // Insert SceneItems too
//            //This is like inserting and linking the keys tgether to link the items to the scene.
//            //Make a new one of these above and below after each new scene made with items.
//            Db.Connection.Insert(new SceneItem
//            {
//                //SceneId = lcMallID,
//                ItemId = x.ItemId
//            });
//            return true;
//        }).ToList<Item>();



//        // Cliff
//        Scene lcCliff = new Scene
//        {
//            StoryName = StoryID.StoryName,
//            //StoryState = "You fell off a cliff"
//        };
//        Db.Connection.Insert(lcCliff);
//        string lcCliffID = lcCliff.SceneID;

//        /* 
//         * Now the SceneDirections
//         * 
//         * Forest, NORTH to Mall
//         * Mall, NORTH to Cliff
//         * Mall, SOUTH to Forest
//         * Cliff, WEST to Forest
//         */
//        //SceneDirection[] lcDirections = {
//        //    new SceneDirection {FromSceneId = lcForestID, ToSceneId = lcMallID, Command = "NORTH"},
//        //    new SceneDirection {FromSceneId = lcMallID, ToSceneId = lcCliffID, Command = "NORTH"},
//        //    new SceneDirection {FromSceneId = lcMallID, ToSceneId = lcForestID, Command = "SOUTH"},
//        //    new SceneDirection {FromSceneId = lcCliffID, ToSceneId = lcForestID, Command = "NORTH"}

//        //};

//        //Db.Connection.InsertAll(lcDirections); // << CHECK THIS WORKS??





//    }

//    //public void GetStoryFirstScene(string pStoryName)
//    //{
//    //    var theStory = Db.Connection.Table<Story>().Where<Story>(
//    //         x => x.StoryName == pStoryName
//    //        ).ToList<Story>().First<Story>();

//    //    _FirstScene = Db.Connection.Table<Scene>().Where<Scene>(
//    //        x => x.SceneID == theStory.FirstSceneID
//    //        ).ToList<Scene>().First<Scene>();
//    //}

//    public void SaveStory()
//    {

//    }

//    public void LoadStory()
//    {

//    }

//}