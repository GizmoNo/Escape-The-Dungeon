﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
/// <summary>
/// Class that deals with a user loging in or registering an account
/// </summary>
public class LoginAndRegister : MonoBehaviour
{
    public static DataService Db = new DataService("Escape The Dungeon.db");
    private Users User = new Users();
    public static Player Player = new Player();
    
    
    
    public InputField UserNameField;
    public InputField PassWordField;
    public Text Error;
    private string UserName;
    private string PassWord;
    private string lcUserNameInput;
    private string lcPassWordInput;
    private string lcUserName;

    private void Start()
    {
        /*
                   Creates database upon starting
                   Will not create it a second time if user hasalready created one
               */
        if (Db.StoryCount() == 0)
        {
            Db.CreateDB();
        }
        /*
                   Sets load value to defult
               */
        SaveDataBetweenScenes.GameInstance.Load = false;
                

    }


    /*
                   Login method that checks to see if the user input is correct or not.
                   If the password is wrong it will display a suitable error message
                   If user does not exists it will display a suitable error message
               */
    public void Login()
    {
        lcUserNameInput = UserNameField.text;
        lcPassWordInput = PassWordField.text;
        

        //User = Db.CheckLoginDetails(lcUserNameInput);
       
      
       

        if (User != null)
        {
            PassWord = User.PassWord;
            if (PassWord == lcPassWordInput)
            {
                Player = Db.CheckPlayerGame(lcUserNameInput);
                if(Player == null)
                {
                    AddPlayer();
                    SaveDataBetweenScenes.GameInstance.UserName = lcUserNameInput;
                    
                    SceneManager.LoadScene("GameScreen");

                }
                else
                {
                    SaveDataBetweenScenes.GameInstance.UserName = lcUserNameInput;
                    
                    SceneManager.LoadScene("GameScreen");




                }
                


            }
            else
            {
                Error.text = "UserName Or PassWord Is Incorrect";
            }
            
        }
        else
        {
            Error.text = "You Must Create An Account";
        }





    }

    /*
                   Register method that will create a new user account
                   If user already exists an apropriate message will be displayed
                   If successful the user will be added to the database and can be used
                   To login again.
               */
    public void Register()
    {
        lcUserNameInput = UserNameField.text;
        lcPassWordInput = PassWordField.text;

        //lcresult = Db.CheckPlayer(lcUserNameInput);
        


        //if (lcresult == null)
        //{
        //    Users lcNewPlayer = new Users()
        //    {
        //        UserName = lcUserNameInput,
        //        PassWord = lcPassWordInput,
        //    };
        //    Db.Connection.Insert(lcNewPlayer);
                        
        //    //User = Db.CheckLoginDetails(lcUserNameInput);
        //    AddPlayer();
        //    SaveDataBetweenScenes.GameInstance.UserName = lcUserNameInput;
            
        //    SceneManager.LoadScene("GameScreen");


        //}
        //else
        //{
        //    Error.text = "Account Already Exists";
        //}


    }

    /*
                  Creates a new player if there player does not exist
               */
    public void AddPlayer()
    {
        
        lcUserName = User.UserName;
        Player = Db.CheckPlayerGame(lcUserName);
        

        if (Player == null)
        {


            Db.Connection.InsertAll(new Player[]
            {
             new Player
             {
                 PlayerEmail = lcUserName,
                 PlayerHP = 100,
                 Playerdamage = 15,
                 CurrentScene = "InCell"

             }

            });
            

        }
        


    }



}
