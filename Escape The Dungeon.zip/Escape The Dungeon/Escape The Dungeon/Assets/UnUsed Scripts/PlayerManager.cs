﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;
using System.Linq;

public class PlayerManager
{
    //private DataService Db = (GameModel.Story != null) ? GameModel.Story.DB : new DataService("ZUp.db"); // Not good because this has already happened in StoryManager???
    //private Player _currentPlayer;
    //private int _logInAttempts = 0;
    //public bool LoggedIn = false;

    //public Player CurrentPlayer
    //{
    //    get
    //    {
    //        return _currentPlayer;
    //    }
    //}
      

    //public Scene CurrentScene()
    //{
    //    Scene result;

    //    result = Db.Connection.Table<Scene>().Where(x =>
    //         x.Id == _currentPlayer.CurrentScene
    //        ).First<Scene>();

    //    return result;
    //}


    //void MoveTo(string pDirection)
    //{
    //    // get the scene where SceneDirection label is pDirection
    //    int lcCurrentSceneId = _currentPlayer.CurrentScene;
    //    SceneDirection lcSceneDirection = Db.Connection.Table<SceneDirection>().Where<SceneDirection>(
    //         x => x.FromSceneId == lcCurrentSceneId & x.Label == pDirection
    //        ).ToList<SceneDirection>().First<SceneDirection>();

    //    int lcNextSceneId = lcSceneDirection.ToSceneId;
    //    Scene lcScene = Db.Connection.Table<Scene>().Where<Scene>(
    //          x => x.Id == lcNextSceneId
    //         ).ToList<Scene>().First<Scene>();

    //    _currentPlayer.CurrentScene = lcScene.Id;

    //    // Update the Current player
    //    Db.Connection.InsertOrReplace(_currentPlayer);

    //}

    //List<Item> GetCurrentSceneItems()
    //{
    //    // Get the SceneItems for the current scene
    //    List<SceneItem> lcSceneItems = Db.Connection.Table<SceneItem>().Where<SceneItem>(
    //          x => x.SceneId == _currentPlayer.CurrentScene
    //         ).ToList<SceneItem>();

    //    // Use the list of scene items, to select items from the items table
    //    List<Item> lcItems = Db.Connection.Table<Item>().Where<Item>(
    //        x =>
    //              lcSceneItems.Where<SceneItem>(y => x.ItemId == y.ItemId).ToList<SceneItem>().Count > 0
    //        ).ToList<Item>();

    //    return lcItems;
    //}
}
