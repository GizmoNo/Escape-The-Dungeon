﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FocusInput : MonoBehaviour
{
    /*
        Sets input field to active making it so player does not have to click input box   
        Does not always work.
    */

    void Start()
    {
        InputField focusMe = gameObject.GetComponent<InputField>();
        focusMe.ActivateInputField();
    }


}
