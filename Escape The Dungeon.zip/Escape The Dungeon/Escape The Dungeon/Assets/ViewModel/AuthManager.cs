﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Firebase;
using Firebase.Auth;
using System.Threading.Tasks;
using System;
/// <summary>
/// Class used to check if login information is corect
/// And
/// Registers new accont when user registers
/// </summary>
public class AuthManager : MonoBehaviour {

    //Firebase APO varibles
    Firebase.Auth.FirebaseAuth auth;
       
    /// <summary>
    /// Sets firebase upto varible on start
    /// </summary>
    private void Awake()
    {
        auth = FirebaseAuth.DefaultInstance;
    }

    public Task<FirebaseUser> theLastTask;
    /// <summary>
    /// Method used when a new account is registered
    /// </summary>
    /// <param name="GoodResultRegister"></param>
    /// <param name="BadResultRegister"></param>
    /// <param name="email"></param>
    /// <param name="password"></param>
    public void NewUser(Action GoodResultRegister, Action BadResultRegister, string email, string password)
    {
        auth.CreateUserWithEmailAndPasswordAsync(email, password).ContinueWith(task =>
        {
            
            theLastTask = task;
            if (task.IsFaulted || task.IsCanceled)
            {
                

                
                Dispatcher.RunOnMainThread(BadResultRegister);

            }
            else if (task.IsCompleted)
            {
               
            Dispatcher.RunOnMainThread(GoodResultRegister);

             }


        });
    }
    /// <summary>
    /// Method authenticates user details with firebase if corect logs person in.
    /// </summary>
    /// <param name="GoodResultlogin"></param>
    /// <param name="BadResultLogin"></param>
    /// <param name="email"></param>
    /// <param name="password"></param>
    public void Login(Action GoodResultlogin, Action BadResultLogin, string email, string password)
    {
        auth.SignInWithEmailAndPasswordAsync(email, password).ContinueWith(task =>
        {
            
            theLastTask = task;
            if (task.IsFaulted || task.IsCanceled)
            {
                                
                Dispatcher.RunOnMainThread(BadResultLogin);

            }
            else if (task.IsCompleted)
            {

                Dispatcher.RunOnMainThread(GoodResultlogin);

            }


        });
    }
}
