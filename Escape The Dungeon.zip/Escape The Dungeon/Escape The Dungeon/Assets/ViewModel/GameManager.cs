﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UManager = UnityEngine.SceneManagement;

/// <summary>
/// Class that deals all the core functions of the game
/// </summary>
public class GameManager : MonoBehaviour
{
    //Puts the game manager in a varible
    public static GameManager instance;

    //checks if game is running
    public bool gameRunning = false;
    //puts game model in varible
    public static GameModel gameModel;

    //Create Canvas in varible
    public Canvas activeCanvas;
    public Canvas GameCanvas;
    public Canvas InventoryCanvas;
    public Canvas MapCanvas;
    public Canvas HomeCanvas;
    public Canvas HelpCanvas;


    //For storing canvases
    private static Dictionary<string, Canvas> canvases;

    //Gets/Sets Canvases
    public static Dictionary<string, Canvas> Canvases
    {
        get
        {
            return canvases;
        }

        set
        {
            canvases = value;
        }
    }
    public void SetCanvases()
    {

    }

    
    /// <summary>
    /// Sets the current active canvas being used
    /// And disables others not being used.
    /// </summary>
    /// <param name="prName"></param>
    public void setActiveCanvas(string prName)
    {

        if (Canvases.ContainsKey(prName))
        {

            // set all to not active;
            foreach (Canvas acanvas in Canvases.Values)
            {
                acanvas.gameObject.SetActive(false);
            }
            activeCanvas = Canvases[prName];
            Debug.Log("I am the active one " + prName);
            //Sets the new canvas to active
            activeCanvas.gameObject.SetActive(true);
        }
        //Error if canvas cannot be found
        else
        {
            Debug.Log("I can not find " + prName + " to make active.");
        }

    }
         
    /// <summary>
    /// Code that runs when scene first loads
    /// Creates all the game objects needed for game play
    /// Also creates an array of canvases to be used when switching between them
    /// </summary>
    void Awake()
    {
        if (instance == null)
        {
            //Making a bunch of varibles needed for game play on start up


            instance = this;
            gameModel = new GameModel();
            instance.gameRunning = true;
            Debug.Log("I am the one");
            if (Canvases == null)
            {
                Canvases = new Dictionary<string, Canvas>();
                Canvases["GameCanvas"] = GameCanvas;
                Canvases["InventoryCanvas"] = InventoryCanvas;
                Canvases["MapCanvas"] = MapCanvas;
                Canvases["HomeCanvas"] = HomeCanvas;
                Canvases["HelpCanvas"] = HelpCanvas;

            }


        }
        else
        {
            Destroy(gameObject);
        }
                         
               
    }


   
    /// <summary>
    /// Checks if game is running
    /// </summary>
    /// <returns> true or false </returns>
    public bool IsGameRunning()
    {
        return gameRunning;
    }

   
} 


