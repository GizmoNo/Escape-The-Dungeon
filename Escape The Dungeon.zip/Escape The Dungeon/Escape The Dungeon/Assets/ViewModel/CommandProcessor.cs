﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using System.IO;

public delegate void aDisplayer(String value);

/// <summary>
/// Class that deals with commands sent by the player
/// </summary>
public class CommandProcessor
{
    public SceneDirection Direction = new SceneDirection();
    public SceneItem SceneItem = new SceneItem();
    public InventoryItem Item = new InventoryItem();
    private int lcPlayerDamage;
    private int lcBossDamage;
    private int lcPlayerHP;
    private int lcBossHP;
    private string lcScene;
    private string lcDirection;
    public string lcOutputText;
    
    /// <summary>
    /// Creates new command processor
    /// </summary>
    public CommandProcessor()
    {
    }

    /// <summary>
    /// Splits the command in to 2 pieces and runs them though a case statement
    /// Depending on the command the database will be updated and other method willbe carried out.
    /// E.g. Change story text, pick item up, change canvas.
    /// </summary>
    /// <param name="prInputText"></param>
    /// <param name="prOutputText"></param>
    public void Parse(String prInputText, aDisplayer prOutputText)
    {
        /*
          Seperates input text into parts
       */


        char[] lcSplitCommand = new char[] { ' ' };
       /*
         Changes all text into lowercase
      */

        prInputText = prInputText.ToLower();

        String[] lcInputTextParts = prInputText.Split(lcSplitCommand, StringSplitOptions.RemoveEmptyEntries);
       /*
          If input text = more than 0 then run otherwise error mesage will show.
      */


        if (lcInputTextParts.Length > 0)
        {
            Debug.Log("I Am Running");


            switch (lcInputTextParts[0])
            {
                /*
                    case 0 = pick then run this code
                */

                case "pick":
                    /*
                        If second part = this then run this code
                   */

                    if (lcInputTextParts[1] == "up")
                    {
                        Debug.Log("Got Pick up");
                        /*
                            Checking to see if a scene object exists
                       */

                        switch (GameManager.gameModel.Player.CurrentScene)
                        {
                            case "TrainingRoom":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.TrainingRoomItem == 1)
                                {
                                    
                                    GameModel.PickUp.TrainingRoomItem = 0;
                                    GameModel.SceneState.TrainingRoomState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,
                                        
                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                            break;
                            case "HallWay":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.HallWayItem == 1)
                                {
                                    GameModel.PickUp.HallWayItem = 0;
                                    GameModel.SceneState.HallWayState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,

                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                                break;
                            case "BreakRoom":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.BreakRoomItem == 1)
                                {
                                    GameModel.PickUp.BreakRoomItem = 0;
                                    GameModel.SceneState.BreakRoomState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,

                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                                break;
                            case "WineCeller":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.WineCellerItem == 1)
                                {
                                    GameModel.PickUp.WineCellerItem = 0;
                                    GameModel.SceneState.WineCellerState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,

                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                                break;
                            case "MapRoom":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.MapRoomItem == 1)
                                {
                                    GameModel.PickUp.MapRoomItem = 0;
                                    GameModel.SceneState.MapRoomState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,

                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                                break;
                            case "StorageRoom":
                                /*
                                        Sets varible to how item has been picked up and for what text
                                        To show on screen.
                                        Updates player inventory database table
                                        Runs story method again to display corect text after varibles
                                        Have chnaged.
                            
                                    */
                                if (GameModel.PickUp.StorageRoomItem == 1)
                                {
                                    GameModel.PickUp.StorageRoomItem = 0;
                                    GameModel.SceneState.StorageRoomState = 3;
                                    SceneItem = GameManager.gameModel.Db.GetCurrentSceneItem(GameManager.gameModel.Player.CurrentScene);
                                    SceneItem.BeenPickedUp = 0;
                                    UpdateSceneItems();
                                    InventoryItem lcNewInventoryItem = new InventoryItem()
                                    {
                                        PlayerName = SaveDataBetweenScenes.GameInstance.UserName,
                                        ItemID = SceneItem.ItemId,

                                    };
                                    GameManager.gameModel.Db.Connection.Insert(lcNewInventoryItem);
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                else
                                {
                                    lcOutputText = "There is nothing to pick up";
                                }

                                break;

                            

                        }
                                         
                                             
                        if (lcInputTextParts.Length == 3)
                        {
                            String param = lcInputTextParts[2];
                        }
                    }
                    prOutputText(lcOutputText);
                    break;

                    //If second part = this then run this code
                case "go":
                    switch (lcInputTextParts[1])
                    {
                        case "north":
                            /*
                                        Gets current scene and command used and sends them to database
                                        If does not come back null will set current new current scene
                                        Will then update player table to show change
                                        Reruns story method to get corect story text.
                            
                                    */

                            lcScene = GameManager.gameModel.Player.CurrentScene;
                            lcDirection = "go north";
                            Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);

                            if (Direction == null)
                            {
                                lcOutputText = "You Walked Into A Wall";
                            }
                            else
                            {
                                GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                GameManager.gameModel.UpdatePlayer();
                                lcOutputText = GameManager.gameModel.Story();
                                
                            }
                            break;

                                                        
                        //Same As Above
                        case "south":
                            /*
                                        Gets current scene and command used and sends them to database
                                        If does not come back null will set current new current scene
                                        Will then update player table to show change
                                        Reruns story method to get corect story text.
                            
                                    */
                            lcScene = GameManager.gameModel.Player.CurrentScene;
                            lcDirection = "go south";
                            Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);
                            
                            if (Direction == null)
                            {
                                lcOutputText = "You Walked Into A Wall";
                            }
                            else
                            {
                                GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                GameManager.gameModel.UpdatePlayer();
                                lcOutputText = GameManager.gameModel.Story();
                                
                            }
                            break;
                           //Same As Above
                        case "east":
                            /*
                                       As the way out from the boss room is east if the player is in
                                       The boss room it checks to see if the boss hp = 0
                                       If not they will get a error message
                                       Game will only allow then to move on if the player has killed
                                       The boss
                                                        
                                       Gets current scene and command used and sends them to database
                                       If does not come back null will set current new current scene
                                       Will then update player table to show change
                                       Reruns story method to get corect story text.
                            
                                    */
                            Debug.Log("Got go East");
                            if (GameManager.gameModel.Player.CurrentScene == "BossRoom")
                            {
                                if (GameManager.gameModel.Boss.HP > 0)
                                {
                                    lcOutputText = "The Boss Is In Your Way You Must Kill Him To Escape Type Attack Boss To Fight";
                                }
                                else
                                {

                                    lcScene = GameManager.gameModel.Player.CurrentScene;
                                    lcDirection = "go east";
                                    Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);

                                    if (Direction == null)
                                    {
                                        lcOutputText = "You Walked Into A Wall";
                                    }
                                    else
                                    {
                                        GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                        GameManager.gameModel.UpdatePlayer();
                                        lcOutputText = GameManager.gameModel.Story();

                                    }
                                }


                            }
                            
                            else
                            {

                                /*
                                        Gets current scene and command used and sends them to database
                                        If does not come back null will set current new current scene
                                        Will then update player table to show change
                                        Reruns story method to get corect story text.
                            
                                    */

                                lcScene = GameManager.gameModel.Player.CurrentScene;
                                lcDirection = "go east";
                                Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);

                                if (Direction == null)
                                {
                                    lcOutputText = "You Walked Into A Wall";
                                }
                                else
                                {
                                    GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                    GameManager.gameModel.UpdatePlayer();
                                    lcOutputText = GameManager.gameModel.Story();

                                }
                                
                            }
                            break;
                            //    //Same As Above
                        case "west":
                            /*
                                        Gets current scene and command used and sends them to database
                                        If does not come back null will set current new current scene
                                        Will then update player table to show change
                                        Reruns story method to get corect story text.
                            
                                    */

                            lcScene = GameManager.gameModel.Player.CurrentScene;
                            lcDirection = "go west";
                            Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);
                            
                            if(Direction == null)
                            {
                                lcOutputText = "You Walked Into A Wall";
                            }
                            else
                            {
                                GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                GameManager.gameModel.UpdatePlayer();
                                lcOutputText = GameManager.gameModel.Story();
                                
                            }
                            


                            break;
                        //Same As Above
                        case "northwest":
                            /*
                                        Gets current scene and command used and sends them to database
                                        If does not come back null will set current new current scene
                                        Will then update player table to show change
                                        Reruns story method to get corect story text.
                            
                                    */
                            lcScene = GameManager.gameModel.Player.CurrentScene;
                            lcDirection = "go northwest";
                            Direction = GameManager.gameModel.Db.GetNewDirection(lcScene, lcDirection);
                            
                            if (Direction == null)
                            {
                                lcOutputText = "You Walked Into A Wall";
                            }
                            else
                            {
                                GameManager.gameModel.Player.CurrentScene = Direction.ToSceneId;
                                GameManager.gameModel.UpdatePlayer();
                                lcOutputText = GameManager.gameModel.Story();
                                
                            }
                            break;
                        //If direction is not posible then this error shows.
                        

                    }
                    prOutputText(lcOutputText);
                    break;
                //If second part = this then run this code
                case "show":
                    switch (lcInputTextParts[1])
                    {
                        /*
                              Shows inventory canvas  
                        */

                        case "inventory":
                            GameManager.instance.setActiveCanvas("InventoryCanvas");
                            break;
                        /*
                            Shows Map Canvas 
                        */

                        case "map":
                            GameManager.instance.setActiveCanvas("MapCanvas");
                            break;
                        /*
                           need to show story text after error message.
                           Will be command to type to reshow story if error message shows up.
                        */

                        case "story":
                            lcOutputText = GameManager.gameModel.Story();
                            prOutputText(lcOutputText);
                            break;

                        /*
                            Show help Canvas
                       */
                        case "help":
                            GameManager.instance.setActiveCanvas("HelpCanvas");
                            break;
                    }
                    break;
                

                case "attack":
                    /*
                           Command used to attack boss
                           When player attacks it will lower boss hp and will also lower
                           Player hp as boss attack them after.
                           If boss hp goes below 0 a message will apare to tell player they can
                           Move on
                    */
                    if (GameManager.gameModel.Player.CurrentScene == "BossRoom")
                    {
                        switch (lcInputTextParts[1])
                        {

                            case "boss":


                                lcPlayerDamage = GameManager.gameModel.Player.Playerdamage;

                                lcBossHP = GameManager.gameModel.Boss.HP;

                                GameManager.gameModel.Boss.HP = lcBossHP - lcPlayerDamage;

                                    if (GameManager.gameModel.Boss.HP <= 0)
                                    {
                                        lcOutputText = "Boss Has Been Killed You See A StairWay To Your East That Leads Outside.";
                                        prOutputText(lcOutputText);
                                }
                                    else
                                    {
                                        lcBossDamage = GameManager.gameModel.Boss.Damage;

                                        lcPlayerHP = GameManager.gameModel.Player.PlayerHP;

                                        GameManager.gameModel.Player.PlayerHP = lcPlayerHP - lcBossDamage;
                                        GameManager.gameModel.UpdatePlayer();
                                    }
                                                                  
                                break;
                        }
                    }
                    else
                    {
                        lcOutputText = "There Is Nothing To Attack";
                    }
                    break;
                case "use":
                    /*
                           Command to use items
                           These items will raise player HP if used by a given amount
                           Deletes item from player inventory after use.

                           Note some items will automaticly give Player benefits upon pickup
                           E.g. Sword.
                    */
                    {
                        switch (lcInputTextParts[1])
                        {
                            case "healthpotion":
                                {
                                    GameManager.gameModel.Player.PlayerHP = GameManager.gameModel.Player.PlayerHP + 50;
                                    Item = GameManager.gameModel.Db.GetInventoryItem(6);
                                    GameManager.gameModel.Db.DeleteItem(Item);
                                    GameManager.gameModel.UpdatePlayer();
                                }
                                break;
                            case "bread":
                                {
                                    GameManager.gameModel.Player.PlayerHP = GameManager.gameModel.Player.PlayerHP + 25;
                                    Item = GameManager.gameModel.Db.GetInventoryItem(3);
                                    GameManager.gameModel.Db.DeleteItem(Item);
                                    GameManager.gameModel.UpdatePlayer();
                                }
                                break;
                        }














                    }
                    break;
                default:
                    lcOutputText = "Comand Unknowen";
                    prOutputText(lcOutputText);
                    break;
                 

            }// end switch
        }


    }
    
    /// <summary>
    /// Sends item object to updated in database
    /// </summary>
    public void UpdateSceneItems()
    {
        GameManager.gameModel.Db.UpdateCurrentSceneItems(SceneItem);
    }
}
