﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Class that deals with loading a new scene when a button is clicked
/// </summary>
public class OnClickSceneChange : MonoBehaviour
{
    
    /// <summary>
    /// Loads new scene
    /// </summary>
    /// <param name="pSceneName"></param>
    public void LoadScene(string pSceneName)
    {

        SceneManager.LoadScene(pSceneName);
    }

    /// <summary>
    /// Quits game/closes application.
    /// </summary>
    public void quitGame()
    {
        Application.Quit();
    }
}
