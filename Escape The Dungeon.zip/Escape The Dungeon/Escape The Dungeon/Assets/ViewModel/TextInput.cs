﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
/// <summary>
/// Class that deals the user input commands
/// </summary>
public class TextInput : MonoBehaviour
{
    InputField input;
    InputField.SubmitEvent Submit;
    
    public Text output;
    private string lcStoryText;
    private LoadGame Load = new LoadGame();

    public float ShakeDetection;
    public float MinSakeInterval;

    private float sqrShakeDetection;
    private float TimeSinceLastShake;



   
    /// <summary>
    ///  Outputs text handed in on the screen
    /// </summary>
    /// <param name="prOutPutText"></param>
    public void OutputText(string prOutPutText)
    {
        output.text = prOutPutText;
    }
      /// <summary>
      /// On start checks if game needs to be loaded or a new game
      /// gets story text and displays it
      /// Sets varibles needed for functionality
      /// </summary>
    void Start()
    {
        /*
                  Gets input component
              */
        input = this.GetComponent<InputField>();
        
        /*
                 If the load button is clicked this will make sure the players stored data
                 Is used
             */
        if (SaveDataBetweenScenes.GameInstance.Load == true)
        {
            Load.Load();
            SaveDataBetweenScenes.GameInstance.Load = false;
        }
        /*
          Runes story script
      */
        lcStoryText = GameManager.gameModel.Story();
        /*
                 Sens text to be displayed on screen
             */
        OutputText(lcStoryText);

        sqrShakeDetection = Mathf.Pow(ShakeDetection, 2);



    }
    
    /// <summary>
    /// Runs when input is submitted
    /// </summary>
    /// <param name="arg0"></param>
    private void ChangeInput(string arg0)
    {
        Debug.Log(arg0);
    }
    /// <summary>
    /// Runs method inside once every frame/second
    /// When phone is shaked the input will be submitted the same as I was clicking enter.
    /// </summary>
    private void Update()
    {
        
        if(Input.acceleration.sqrMagnitude >= ShakeDetection && Time.unscaledTime >= TimeSinceLastShake + MinSakeInterval)
        {
            /*
                 instantiates of new CommandProcessor
             */
            CommandProcessor Commands = new CommandProcessor();
            /*
                     runs other code to check different parts to get correct output back and displayed.
                 */

            Commands.Parse(input.text, OutputText);
            /*
                     Takes text out of input box
                 */
            input.text = "";
            
            
        }
    }

}
