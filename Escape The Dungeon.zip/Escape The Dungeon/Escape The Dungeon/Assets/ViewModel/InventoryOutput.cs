﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// Class that displays items and gives bonuses when player picks them up
/// </summary>
public class InventoryOutput : MonoBehaviour
{
    public Text output;
    private string lcPlayerName;
    private string lcstring;
    private List<Item> _InventoryItems = new List<Item>();
    private int lcItemID;
    private int lcSwordHasBeenAdded = 1;
    private int lcRockHasBeenAdded = 1;
    private int lcBreadHasBeenAdded = 1;
    private int lcMapHasBeenAdded = 1;
    private int lcCrudeArmorHasBeenAdded = 1;
    private int lcHealthPotionHasBeenAdded = 1;
    

    public List<Item> InventoryItems
    {
        get
        {
            return _InventoryItems;
        }

        set
        {
            _InventoryItems = value;
        }
    }
    /// <summary>
    /// Updates the inventory of a player.
    /// Checks to see if item is in SQL light table and adds it to database
    /// Has a varible so item does not get added more than once
    /// </summary>
    void Update()
    {
        lcPlayerName = SaveDataBetweenScenes.GameInstance.UserName;
        List<InventoryItem> Inventory = new List<InventoryItem>();
        Inventory = GameManager.gameModel.Db.GetAllInventoryItems(lcPlayerName);
        /*
        Adds items to players inventory if picked up
        if item hs been picked up a value will be chnaged to 0 so it does not run again.
        if an item give a boost in stats it happens here upon pick up of the item.
        */
        foreach (InventoryItem lcInv in Inventory)
        {
            if(lcInv.PlayerName == SaveDataBetweenScenes.GameInstance.UserName)
            {
                /*
                    Sword Item
                */
                if (lcSwordHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item Sword = new Item();
                    Sword = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(Sword);
                    lcSwordHasBeenAdded = 0;
                    GameManager.gameModel.Player.Playerdamage = GameManager.gameModel.Player.Playerdamage + 10;
                    GameManager.gameModel.UpdatePlayer();
                }
                
            }
            /*
                    Rock Item
                */
            if (lcInv.ItemID == 2)
            {
                if (lcRockHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item Rock = new Item();
                    Rock = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(Rock);
                    lcRockHasBeenAdded = 0;
                }
            }
            /*
                    Bread Item
                */
            if (lcInv.ItemID == 3)
            {
                if (lcBreadHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item Bread = new Item();
                    Bread = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(Bread);
                    lcBreadHasBeenAdded = 0;
                    
                }
            }
            /*
                    Map Item
                */
            if (lcInv.ItemID == 4)
            {
                if (lcMapHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item Map = new Item();
                    Map = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(Map);
                    lcMapHasBeenAdded = 0;
                }
            }
            /*
                    Armor Item
                */
            if (lcInv.ItemID == 5)
            {
                if (lcCrudeArmorHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item CrudeArmor = new Item();
                    CrudeArmor = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(CrudeArmor);
                    lcCrudeArmorHasBeenAdded = 0;
                    GameManager.gameModel.Boss.Damage = GameManager.gameModel.Boss.Damage - 10;
                }
            }
            /*
                    Healthpotion Item
                */
            if (lcInv.ItemID == 6)
            {
                if (lcHealthPotionHasBeenAdded == 1)
                {
                    lcItemID = lcInv.ItemID;
                    Item HealthPotion = new Item();
                    HealthPotion = GameManager.gameModel.Db.GetItem(lcItemID);
                    InventoryItems.Add(HealthPotion);
                    lcHealthPotionHasBeenAdded = 0;
                    
                }
            }
        }

        /*
                    Loop that displays the items within the a list of items
                */
        if (InventoryItems != null)
        {


            output.text = null;
            foreach (Item prItem in InventoryItems)
            {
                output.text = output.text + "\n" + prItem.Description;

            }
        }
        else
        {
            output.text = "Inventory Is Empty";
        }
         


    }
}
