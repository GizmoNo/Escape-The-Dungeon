﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// Class that deals with enableing and disableing canvases
/// </summary>
public class LoadOnClickCanvas : MonoBehaviour
{
    
   /// <summary>
   /// Changes canvas when a button is clicked in UI 
   /// Canvas object is sent to this method from unity interface.
   /// </summary>
   /// <param name="pCanvas"></param>
    public void ChangeCanvas(Canvas pCanvas)
    {
        pCanvas.gameObject.SetActive(true);

        Canvas[] canvases = gameObject.GetComponentsInChildren<Canvas>();

        foreach (Canvas aCvn in canvases)
        {
            if (aCvn.name != pCanvas.name)
            {
                aCvn.gameObject.SetActive(false);
            }
        }
    }
    
    /// <summary>
    /// Changes canvas when a button is clicked in UI 
    /// Is the duplicate of the method above but this has an added piece of code
    /// so they the program will know the player wants to load a previous save.
    /// </summary>
    /// <param name="pCanvas"></param>
    public void ChangeCanvasLoad(Canvas pCanvas)
    {
        pCanvas.gameObject.SetActive(true);
        SaveDataBetweenScenes.GameInstance.Load = true;
        Canvas[] canvases = gameObject.GetComponentsInChildren<Canvas>();

        foreach (Canvas aCvn in canvases)
        {
            if (aCvn.name != pCanvas.name)
            {
                aCvn.gameObject.SetActive(false);
            }
        }
    }
}
