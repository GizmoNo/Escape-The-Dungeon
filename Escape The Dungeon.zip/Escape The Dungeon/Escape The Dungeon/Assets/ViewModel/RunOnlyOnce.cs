﻿using System.Collections;
using UnityEngine;
/// <summary>
/// Class that runs only once when game first starts
/// </summary>
public class RunOnlyOnce : MonoBehaviour
{

    public static RunOnlyOnce instance;
    /// <summary>
    /// If instance already exists it will be destroyed
    /// </summary>
    void Awake()
    {
        
        if (instance != null && instance != this)
        {
            DestroyImmediate(gameObject);
            return;
        }
        instance = this;
                
    }
}
