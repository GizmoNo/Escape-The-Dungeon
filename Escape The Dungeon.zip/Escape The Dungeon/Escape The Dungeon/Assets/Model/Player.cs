﻿using System;
using System.Collections.Generic;
using SQLite4Unity3d;

/// <summary>
/// Class that creates the player database table
/// </summary>
public class Player
{
         
    [NotNull]                 
    public string CurrentScene { get; set; }
    [PrimaryKey]
    public string PlayerEmail { get; set; }
    [NotNull]
    public int PlayerHP { get; set; }
    [NotNull]
    public int Playerdamage { get; set; }
 

}




    
    




