﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;

///<summary>
/// Class that creates the enemy database table
///</summary>
public class Enemy
{
    [PrimaryKey]
    public string EnemyName { get; set; }
    [NotNull]
    public int HP { get; set; }
    [NotNull]
    public int Damage { get; set; }
    



   
	
}
