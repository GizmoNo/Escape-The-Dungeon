﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
[RequireComponent(typeof(Image))]
///<summary>
/// Class that Handles and monitors player health
/// If player health drops below 40 heart image is replaced with a white heart.
/// If health is regained image will switch back
///</summary>
public class UpdateHP60 : MonoBehaviour
{


    public Sprite Health60, HealthDamage;


    /// <summary>
    /// Sets sprites to a varible
    /// </summary>
    void Start()
    {


        Health60 = Resources.Load<Sprite>("Heart60");
        HealthDamage = Resources.Load<Sprite>("HeartDamage");


    }



    /// <summary>
    /// Checks to see if HP goes below a certain amount and if it does the sprite will chnage.
    /// </summary>
    void Update()
    {
        Image image;
        if ((image = gameObject.GetComponent<Image>()))

            if (GameManager.gameModel.Player.PlayerHP <= 40)
            {

                image.sprite = HealthDamage;


            }
            else
            {
                image.sprite = Health60;
            }
    }
}
