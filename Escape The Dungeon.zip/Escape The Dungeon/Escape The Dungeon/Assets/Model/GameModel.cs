﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

///<summary>
/// This class creates all the base game varibles and updates text within the game when
/// An action is done 
///</summary>
public class GameModel
{
    //Name of scenes
    private string _currentScene;
    private String _name;
    private string lcPlayerID;
    private int lcCurrentSceneState;
    
    private int lcItemID;

    // instantiation of new Player set to a varible
    public Player Player = new Player();
    //Sets direction controlls
   
    

    
   
    public Scene GameScenes = new Scene();
    public Enemy Boss = new Enemy();
    public DataService Db = new DataService("Escape The Dungeon.db");
    public static SceneStates SceneState = new SceneStates();
    public static ItemPickUp PickUp = new ItemPickUp();
    private Story StoryDetails = new Story();
    public Item Item = new Item();
    public Item GameItem = new Item();
    private int lcDamage;


    /*
      Runs when new game model is created
      Runs several methods to set defalts for game play
    */
    /// <summary>
    /// Runs methods needed for game play when a new gameModel is made
    /// </summary>
    public GameModel()
    {
             
        
            GetBossData();
            GetPlayer();
            SetSceneStates();
            SetItemPickUp();
                  
        
    }

    /*
      Sets an incode value for the states of the scene upon new game.
      Saves space so I don't have to pull this data out of the database
      It will be updated in the database when nessasary.
    */
    /// <summary>
    /// Sets the state of all game scenes
    /// </summary>
    private void SetSceneStates()
    {
        SceneState.InCellState = 1;
        SceneState.HallWayState = 1;
        SceneState.MapRoomState = 1;
        SceneState.OutSideFredomState = 1;
        SceneState.StorageRoomState = 1;
        SceneState.TrainingRoomState = 1;
        SceneState.WineCellerState = 1;
        SceneState.BreakRoomState = 1;
        SceneState.BossRoomState = 1;
    }

    /*
      Code that runs on an update method within TextInput
            
    */
    /// <summary>
    /// Gets the corect story text based on the currernt scene and scene state
    /// </summary>
    /// <returns> Story text back to the command processer </returns>
     
    public string Story()
    {

        /*
           First it gets the current scene player is in from the database
        */
        GameScenes = Db.GetCurrentScene(Player.CurrentScene);

        switch (Player.CurrentScene)
        {
            case "InCell":
                {
                    lcCurrentSceneState = SceneState.InCellState;
                }
                break;
            case "TrainingRoom":
                {
                    lcCurrentSceneState = SceneState.TrainingRoomState;
                }
                break;
            case "HallWay":
                {
                    lcCurrentSceneState = SceneState.HallWayState;
                }
                break;
            case "StorageRoom":
                {
                    lcCurrentSceneState = SceneState.StorageRoomState;
                }
                break;
            case "MapRoom":
                {
                    lcCurrentSceneState = SceneState.MapRoomState;
                }
                break;
            case "BreakRoom":
                {
                    lcCurrentSceneState = SceneState.BreakRoomState;
                }
                break;
            case "WineCeller":
                {
                    lcCurrentSceneState = SceneState.WineCellerState;
                }
                break;
            case "BossRoom":
                {
                    lcCurrentSceneState = SceneState.BreakRoomState;
                }
                break;
            case "OutSideFredom":
                {
                    lcCurrentSceneState = SceneState.OutSideFredomState;
                }
                break;
                


        }

        /*
          Second It uses that State to get the corect story text out of the database.
          If the state is 3 for a user picking up an item it will change it back to
          A state of 2 so next visit will not have any item text.
          It also updates the new state in the database.
       */
        StoryDetails = Db.GetCurrentStory(Player.CurrentScene,lcCurrentSceneState);

        switch (Player.CurrentScene)
        {
            case "InCell":
                {
                    SceneState.InCellState = StoryDetails.State;
                }
                break;
            case "TrainingRoom":
                {
                    if (SceneState.TrainingRoomState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.TrainingRoomState = 2;
                        
                    }
                    UpdateSceneState();

                }
                break;
            case "HallWay":
                {
                    if (SceneState.HallWayState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.HallWayState = 2;
                    }
                    UpdateSceneState();
                }
                break;
            case "StorageRoom":
                {
                    if (SceneState.StorageRoomState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.StorageRoomState = 2;
                    }
                    UpdateSceneState();
                }
                break;
            case "MapRoom":
                {
                    if (SceneState.MapRoomState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.MapRoomState = 2;
                    }
                    UpdateSceneState();
                }
                break;
            case "BreakRoom":
                {
                    if (SceneState.BreakRoomState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.BreakRoomState = 2;
                    }
                    UpdateSceneState();
                }
                break;
            case "WineCeller":
                {
                    if (SceneState.WineCellerState == 3)
                    {
                        GameScenes.SceneState = 2;
                        SceneState.WineCellerState = 2;
                    }
                    UpdateSceneState();
                }
                break;
            case "BossRoom":
                {
                    SceneState.BossRoomState = StoryDetails.State;
                }
                break;
            case "OutSideFredom":
                {
                    SceneState.OutSideFredomState = StoryDetails.State;
                }
                break;

                

        }
        /*
          Third The Story next is put into a varible and returned back to TextInput
       */
        string lcStoryText;
        lcStoryText = StoryDetails.Description;
        return lcStoryText;
        



    }

    /*
        Sets defults for if items have been picked up or not
    */
    /// <summary>
    /// Sets Item state to not picked up in each scene
    /// </summary>
    private void SetItemPickUp()
    {
        PickUp.WineCellerItem = 1;
        PickUp.TrainingRoomItem = 1;
        PickUp.HallWayItem = 1;
        PickUp.MapRoomItem = 1;
        PickUp.StorageRoomItem = 1;
        PickUp.BreakRoomItem = 1;
    }



    /*
          Gets the current player and puts it into a class to be used though out the 
          Program
    */
    /// <summary>
    /// Gets player from SQL light database and sets it in code for use
    /// </summary>
    public void GetPlayer()
    {
        lcPlayerID = SaveDataBetweenScenes.GameInstance.UserName;

        Player = Db.CheckPlayerGame(lcPlayerID);

        
    }
    /*
          Gets the Boss stats and puts them in a class to be used within the program
    */
    /// <summary>
    /// Gets boss data from SQL light database and sets it in code
    /// </summary>
    private void GetBossData()
    {
        Boss = Db.GetEnemyStats("Boss");
    }

    /*
          Sends whole player object to method to update database
    */
    /// <summary>
    /// Updates player in SQL light database when needed
    /// </summary>
    public void UpdatePlayer()
    {
        GameManager.gameModel.Db.UpdateCurrentScene(Player);
    }
    /*
         Sends whole scene object to database to be updated
    */
    /// <summary>
    /// Updates the state of the scene in SQL light datbase
    /// </summary>
    public void UpdateSceneState()
    {
        GameManager.gameModel.Db.UpdateCurrentSceneState(GameScenes);
    }
    


}
