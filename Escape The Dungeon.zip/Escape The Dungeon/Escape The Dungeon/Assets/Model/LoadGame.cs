﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Class that loads a users information from a previous created game
/// </summary>
public class LoadGame {

    private string lcPlayerName;
    /*
          Method that gets players information from the database and run it though a 
          Loop and sets the players stats there corasponding areas to be used 
    */
    /// <summary>
    /// When game is loaded this method gets information from the SQL light datbase and sets the scene and item states
    /// as we do not want them to be set as defult
    /// </summary>
    public void Load()
    {

        lcPlayerName = SaveDataBetweenScenes.GameInstance.UserName;
        List<Scene> Scenes = new List<Scene>();
        Scenes = GameManager.gameModel.Db.GetPlayerScenes(lcPlayerName);

        lcPlayerName = SaveDataBetweenScenes.GameInstance.UserName;
        List<SceneItem> SceneItems = new List<SceneItem>();
        SceneItems = GameManager.gameModel.Db.NewGameGetOldSceneItems(lcPlayerName);

        /*
          Sets Scene States
       */
        foreach (Scene lcScene in Scenes)
        {
            if (lcScene.PlayerName == lcPlayerName)
            {
                if (lcScene.SceneID == "InCell")
                {
                    GameModel.SceneState.InCellState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "TrainingRoom")
                {
                    GameModel.SceneState.TrainingRoomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "BreakRoom")
                {
                    GameModel.SceneState.BreakRoomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "MapRoom")
                {
                    GameModel.SceneState.MapRoomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "StorageRoom")
                {
                    GameModel.SceneState.StorageRoomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "BossRoom")
                {
                    GameModel.SceneState.BreakRoomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "WineCeller")
                {
                    GameModel.SceneState.WineCellerState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "OutSideFredom")
                {
                    GameModel.SceneState.OutSideFredomState = lcScene.SceneState;
                }
                if (lcScene.SceneID == "HallWay")
                {
                    GameModel.SceneState.HallWayState = lcScene.SceneState;
                }
            }
        }

        /*
          Sets Item States
       */
        foreach (SceneItem lcSceneItem in SceneItems)
        {
            if (lcSceneItem.PlayerName == lcPlayerName)
            {
                if (lcSceneItem.SceneId == "BreakRoom")
                {
                    GameModel.PickUp.BreakRoomItem = lcSceneItem.BeenPickedUp;
                }
                if (lcSceneItem.SceneId == "TrainingRoom")
                {
                    GameModel.PickUp.TrainingRoomItem = lcSceneItem.BeenPickedUp;
                }
                if (lcSceneItem.SceneId == "HallWay")
                {
                    GameModel.PickUp.HallWayItem = lcSceneItem.BeenPickedUp;
                }
                if (lcSceneItem.SceneId == "MapRoom")
                {
                    GameModel.PickUp.MapRoomItem = lcSceneItem.BeenPickedUp;
                }
                if (lcSceneItem.SceneId == "StorageRoom")
                {
                    GameModel.PickUp.StorageRoomItem = lcSceneItem.BeenPickedUp;
                }
                if (lcSceneItem.SceneId == "WineCeller")
                {
                    GameModel.PickUp.WineCellerItem = lcSceneItem.BeenPickedUp;
                }

            }
        }











    }
}
