﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class that holds a value that will be used to tell if the player has picked up an
/// the item or not
/// </summary>
public class ItemPickUp
{
    /*
          Filled with OO style based Gets and Sets
    */
    private int _hallWayItem;
    private int _trainingRoomItem;
    private int _storageRoomItem;
    private int _mapRoomItem;
    private int _breakRoomItem;
    private int _wineCellerItem;

    

    public int HallWayItem
    {
        get
        {
            return _hallWayItem;
        }

        set
        {
            _hallWayItem = value;
        }
    }

    public int TrainingRoomItem
    {
        get
        {
            return _trainingRoomItem;
        }

        set
        {
            _trainingRoomItem = value;
        }
    }

    public int StorageRoomItem
    {
        get
        {
            return _storageRoomItem;
        }

        set
        {
            _storageRoomItem = value;
        }
    }

    public int MapRoomItem
    {
        get
        {
            return _mapRoomItem;
        }

        set
        {
            _mapRoomItem = value;
        }
    }

    public int BreakRoomItem
    {
        get
        {
            return _breakRoomItem;
        }

        set
        {
            _breakRoomItem = value;
        }
    }

    public int WineCellerItem
    {
        get
        {
            return _wineCellerItem;
        }

        set
        {
            _wineCellerItem = value;
        }
    }
}
