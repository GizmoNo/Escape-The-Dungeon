﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
///Code Used for switching backgrounds as player goes though scenes
/// </summary>

[RequireComponent(typeof(Image))]
public class SwitchBackGround : MonoBehaviour 
{
    //Sets variable to store background image in.
    public Sprite InCellImage, TrainingRoomImage, HallWayImage, StoreRoomImage, MapRoomImage, BreakRoomImage, WineCellerImage, BossRoomImage, OutSideFredomImage;
    /// <summary>
    /// Sets all sprites to a varible
    /// </summary>
    private void Start()
    {
        /*
          Gets and sets the background image to the varible
       */

        TrainingRoomImage = Resources.Load<Sprite>("TrainingRoomImage");
        InCellImage = Resources.Load<Sprite>("InCellImage");
        HallWayImage = Resources.Load<Sprite>("HallWayImage");
        StoreRoomImage = Resources.Load<Sprite>("StoreRoomImage");
        BreakRoomImage = Resources.Load<Sprite>("BreakRoomImage");
        WineCellerImage = Resources.Load<Sprite>("WineCellerImage");
        BossRoomImage = Resources.Load<Sprite>("BossRoomImage");
        MapRoomImage = Resources.Load<Sprite>("MapRoomImage");
        OutSideFredomImage = Resources.Load<Sprite>("OutSideFredomImage");
               

    }
    /// <summary>
    /// Constantly running switch background method
    /// </summary>
    private void Update()
    {
        /*
          Constanly runs/updates background when needed
       */
        SwitchBackground();
    }


    //Player Area = new Player();
    private Image Background;

    /// <summary>
    /// Goes though and check to see what the current scene is.
    /// Depending on the scene the back ground image will change.
    /// </summary>
    public void SwitchBackground()
    {
        /*
           Gets the component image form unity interface
       */

        Image image;
        if (!(image = gameObject.GetComponent<Image>()))
            Debug.Log("I have no Image component! Fix meeeeeeeeeeeee");
        /*
            Gets current scene and name from player
            Scene Not being set before this is run.
        */

        switch (GameManager.gameModel.Player.CurrentScene)
        {
            /*
              All code below is checking for the name and will change the 
              Background acordingly.
           */


            case ("InCell"):
                {

                    image.sprite = InCellImage;


                }
                break;

            case ("TrainingRoom"):
                {

                    image.sprite = TrainingRoomImage;


                }
                break;

            case ("HallWay"):
                {

                    image.sprite = HallWayImage;


                }
                break;

            case ("StorageRoom"):
                {

                    image.sprite = StoreRoomImage;


                }
                break;

            case ("MapRoom"):
                {

                    image.sprite = MapRoomImage;


                }
                break;

            case ("BreakRoom"):
                {


                    image.sprite = BreakRoomImage;

                }
                break;

            case ("WineCeller"):
                {

                    image.sprite = WineCellerImage;


                }
                break;

            case ("OutSideFredom"):
                {

                    image.sprite = OutSideFredomImage;


                }
                break;

            case ("BossRoom"):
                {

                    image.sprite = BossRoomImage;


                }
                break;
        }


    }





}
