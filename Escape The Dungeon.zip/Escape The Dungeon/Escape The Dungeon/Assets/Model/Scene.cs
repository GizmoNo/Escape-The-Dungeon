﻿using System;
using System.Collections.Generic;
using SQLite4Unity3d;

/// <summary>
/// Class that creates the scene database table
/// </summary>
public class Scene
{
    [PrimaryKey,AutoIncrement]
    public int ID { get; set; }
    [NotNull]
    public string PlayerName { get; set; }
    [NotNull]
    public string SceneID { get; set; }
    [NotNull]
    public int SceneState { get; set; }
    

    


}
