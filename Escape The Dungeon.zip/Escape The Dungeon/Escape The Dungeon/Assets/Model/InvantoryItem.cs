﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;

/// <summary>
/// Class that creates the Inventoryitem database table
/// </summary>
public class InventoryItem
{
    [PrimaryKey, AutoIncrement]
    public int ID { get; set; }
    [NotNull]
    public string PlayerName { get; set; }
    [NotNull]
    public int ItemID { get; set; }
	
}
