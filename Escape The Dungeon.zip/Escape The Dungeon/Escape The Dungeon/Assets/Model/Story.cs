﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;
/// <summary>
/// Class that creates the story database table
/// </summary>
public class Story
{
    [NotNull]
    public string StoryName { get; set; }
    [NotNull]
    public int State { get; set; }
    [NotNull]
    public string Description { get; set; }
    public string FirstSceneID { get; set; }
    [NotNull]
    public string SceneID { get; set; }
}
