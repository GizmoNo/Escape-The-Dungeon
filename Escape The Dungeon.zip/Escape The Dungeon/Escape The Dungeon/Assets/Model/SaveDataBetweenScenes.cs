﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Class that holds data that needs to be saved from different unity scenes and data
/// that can be gotten from anywhere within the program
/// </summary>
public class SaveDataBetweenScenes : MonoBehaviour
{
    public static SaveDataBetweenScenes GameInstance = null;
    private static Player player = new Player();
    public bool load;
    

    private string _userName;
    /*
         Saves Username
         Saves load bool
         Saves Player Object
         Set so this does not get destoryed when navigating though scenes
    */
    public static Player Player
    {
        get
        {
            return player;
        }

        set
        {
            player = value;
        }
    }

    public bool Load
    {
        get
        {
            return load;
        }

        set
        {
            load = value;
        }
    }

    public string UserName
    {
        get
        {
            return _userName;
        }

        set
        {
            _userName = value;
        }
    }

    
    /// <summary>
    /// Singleton class.
    /// Makes sure object is not destoryed when swaping between scenes
    /// </summary>
    private void Awake()
    {
        if(GameInstance == null)
        {
            GameInstance = this;
        }
        else if(GameInstance != this)
        {
            Destroy(gameObject);
        }
        

        DontDestroyOnLoad(gameObject);
    }
}
