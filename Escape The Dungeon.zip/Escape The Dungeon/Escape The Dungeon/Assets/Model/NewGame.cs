﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Class that calls a method to reset player stats in database
/// Currently does not work if you try create a game a second time with the same account
/// </summary>
public class NewGame : MonoBehaviour
{
    private string lcPlayerName;
    /// <summary>
    /// When new game is created sets all game data to defult.
    /// Mostly needed when a new game is created after player as already player the game
    /// </summary>
    public void StartNewGame()
    {
        LoginAndRegister.Db.NewGame();
        
    }
    



}
